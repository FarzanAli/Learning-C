/**
 * Student type stores _student with fields first_name, last_name, id, grades, and num_grades.
 * @file student.h
 * */ 
typedef struct _student 
{ 
  char first_name[50]; /**<stores student's first name.*/
  char last_name[50]; /**<stores student's last name.*/
  char id[11]; /**<stores student's id.*/
  double *grades; /**<stores student's grades.*/
  int num_grades; /**<stores number of grades student has.*/
} Student;

//Adds grade to student object.
void add_grade(Student *student, double grade);

//Calculates a student's average in all courses.
double average(Student *student);

//Prints student's information such as name, ID, grades, and average.
void print_student(Student *student);

//Generates random student with a random name, id, and grades
Student* generate_random_student(int grades); 
