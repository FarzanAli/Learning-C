/**
 * Course type stores a _course with fields name, code, students, and total_students.
 * @file course.h
 */

#include "student.h"
#include <stdbool.h>
 
typedef struct _course 
{
  char name[100];/**<Names course*/
  char code[10];/**<Course code*/
  Student *students;/**<Students array which will be dynamically allocated*/
  int total_students;/**<Keeps track of total students in course*/
} Course;

//Enrolls student in given course.
void enroll_student(Course *course, Student *student);

//Prints course information such as name, code, and total students..
void print_course(Course *course);

//Finds student with highest mark.
Student *top_student(Course* course);

//Finds number of students that are passing given course.
Student *passing(Course* course, int *total_passing);


