#include <stdio.h>
#include "library.h"

int main(int argc, char *argv[])
{
	int value = 0;
	while(scanf("%d", &value) != EOF){
		printf("%d %s\n", square_area(value), argv[1]);
	}
	return 0;
}
