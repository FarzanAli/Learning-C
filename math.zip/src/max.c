#include <stdio.h>
#include <stdlib.h>
#include "library.h"

int main(int argc, char *argv[])
{ 
	int *array = calloc(argc - 1, sizeof(int));

	for(int i = 0; i < argc - 1; i++){
		array[i] = atoi(argv[i + 1]);
	}

	printf("%d\n", max(array, argc - 1));

	return 0;
}
