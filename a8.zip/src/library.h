/*******************************************************************************
*
* Purpose: Library functions header file
*
* Author: Kevin Browne
*
*******************************************************************************/
int square_area(int side);
int multiply(int m, int n);
int max(int array[], int total);