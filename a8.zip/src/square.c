/*******************************************************************************
*
* Purpose: Square area calculator.  Outputs caculated square areas from 
* side length provided via standard input... outputs them with a unit 
* provided as 2nd argv values.  i.e. if we run with ""./square inches" expect 
* output of the format: 50 inches
*
*******************************************************************************/
#include <stdio.h>
#include "library.h"

int main(int argc, char *argv[])
{
	int value = 0;
	while(scanf("%d", &value) != EOF){
		printf("%d %s\n", square_area(value), argv[1]);
	}
	return 0;
}
